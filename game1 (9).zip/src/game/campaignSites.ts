import type { WorldData, Rect, Zone, PoiDef, StructKind } from './world';
import type { Facility, FacilityGuard, PropKind } from './facilities';
import type { Block, Point } from './navigation';

export const GOLIATH = { x: 2800, y: 4520, w: 2160, h: 1700 };
export const MNEMOSYNE = { x: 2330, y: 2600, w: 920, h: 740 };
export interface PatrolRoute { id: string; points: Point[]; members: string[] }
export interface LibraryVolume extends Point { number: number; read: boolean }
export interface CampaignSites {
  warehouse: Block; library: Block; volumes: LibraryVolume[];
  patrols: PatrolRoute[]; librarySolved: boolean; libraryProgress: number;
}

interface Context {
  rects: Rect[]; zones: Zone[]; pois: PoiDef[]; facilities: Facility[]; guards: FacilityGuard[];
  gates: Point[]; vans: WorldData['vanSpots']; caches: Point[];
  lights: WorldData['spotlightSpots']; barrels: Point[];
}

export function addCampaignSites(c: Context): CampaignSites {
  const depot = { x: GOLIATH.x - GOLIATH.w / 2, y: GOLIATH.y - GOLIATH.h / 2, w: GOLIATH.w, h: GOLIATH.h };
  const archive = { x: MNEMOSYNE.x - MNEMOSYNE.w / 2, y: MNEMOSYNE.y - MNEMOSYNE.h / 2, w: MNEMOSYNE.w, h: MNEMOSYNE.h };
  const add = (x: number, y: number, w: number, h: number, kind: StructKind, height = 34, detail = false) => {
    c.rects.push({ x, y, w, h, kind, h3d: height, facilityDetail: detail });
  };
  const enclose = (b: Block, kind: StructKind, gap: number, thickness = 32) => {
    const cx = b.x + b.w / 2;
    for (const y of [b.y, b.y + b.h - thickness]) {
      add(b.x, y, (b.w - gap) / 2, thickness, kind);
      add(cx + gap / 2, y, (b.w - gap) / 2, thickness, kind);
    }
    add(b.x, b.y + thickness, thickness, b.h - thickness * 2, kind);
    add(b.x + b.w - thickness, b.y + thickness, thickness, b.h - thickness * 2, kind);
    const doors = [{ x: cx, y: b.y + thickness / 2 }, { x: cx, y: b.y + b.h - thickness / 2 }];
    c.gates.push(...doors); return doors;
  };
  const prop = (f: Facility, kind: PropKind, x: number, y: number, w: number, h: number, solid = true, color = '#b6c1b8') => {
    f.props.push({ kind, x, y, w, h, solid, color });
    if (solid) add(x, y, w, h, f.kind, 27, true);
  };
  c.zones.push({ x: depot.x - 45, y: depot.y - 45, w: depot.w + 90, h: depot.h + 90, kind: 'concrete' });
  const entrances = enclose(depot, 'curtain', 340, 36);
  c.pois.push({ id: 'goliath', kind: 'depot', x: GOLIATH.x, y: GOLIATH.y, r: 1350, name: 'GOLIATH LOGISTICS FORTRESS', sub: 'WAREHOUSING / MOTOR COLUMNS / FLIGHT CARGO', secret: false, gates: entrances });
  for (let row = 0; row < 2; row++) for (let col = 0; col < 2; col++) {
    const b = { x: depot.x + (col ? depot.w - 865 : 85), y: depot.y + (row ? 1145 : 90), w: 780, h: 410 };
    const number = row * 2 + col + 1;
    const doors = enclose(b, 'warehouse', 280, 27);
    const f: Facility = { ...b, id: `goliath-bay-${number}`, kind: 'warehouse', name: ['ORDNANCE RECEIVING', 'VEHICLE PARTS', 'QUANTUM FREIGHT', 'STRATEGIC RESERVES'][number - 1], code: `GL-${number}`, props: [], roofed: true, doors };
    c.facilities.push(f);
    for (const side of [0, 1]) for (let y = 0; y < 2; y++) {
      const x = b.x + (side ? 522 : 49), yy = b.y + 55 + y * 154;
      prop(f, 'pallet', x, yy, 181, 98, true, side ? '#bc9670' : '#829a87');
      add(x + 14, yy + 109, 43, 33, 'crate', 22);
    }
    prop(f, 'console', b.x + 494, b.y + 334, 171, 33, false);
    c.caches.push({ x: b.x + b.w / 2 + 67, y: b.y + 103 });
    const crew = ['commander', 'warden', 'breacher', 'gunner', 'medic', 'guard', 'sapper', 'pathfinder'];
    crew.forEach((type, i) => c.guards.push({
      x: b.x + b.w / 2 + (i % 2 ? 66 : -66), y: b.y + 76 + Math.floor(i / 2) * 73,
      type, facilityId: f.id, role: i === 0 ? 'leader' : i === 4 ? 'support' : i % 3 === 0 ? 'flank' : 'screen', patrol: [],
    }));
  }
  // Neat vehicle ranks and two unobstructed central cargo lanes.
  for (let row = 0; row < 2; row++) for (let col = 0; col < 8; col++) {
    c.vans.push({ x: depot.x + 160 + col * 250, y: depot.y + 625 + row * 305, ang: Math.PI / 2 });
  }
  c.zones.push({ x: GOLIATH.x - 110, y: depot.y + depot.h, w: 220, h: 480, kind: 'road' });
  for (const x of [depot.x + 40, depot.x + depot.w - 40]) for (const y of [depot.y + 35, depot.y + depot.h - 35]) {
    c.lights.push({ x, y, speed: 0.53, sweep: 1.05 });
  }
  for (let i = 0; i < 8; i++) c.barrels.push({ x: depot.x + 72 + i % 2 * 51, y: depot.y + 705 + Math.floor(i / 2) * 49 });

  // Mnemosyne: a deliberately quiet, pre-digital archive hidden off the main route.
  c.zones.push({ x: archive.x - 35, y: archive.y - 35, w: archive.w + 70, h: archive.h + 95, kind: 'plaza' });
  const libraryDoors = enclose(archive, 'library', 210, 32);
  const library: Facility = { ...archive, id: 'mnemosyne', code: 'SSR-0', kind: 'library', name: 'MNEMOSYNE LIBRARY', props: [], roofed: true, doors: libraryDoors };
  c.facilities.push(library);
  c.pois.push({ id: 'mnemosyne', kind: 'library', x: MNEMOSYNE.x, y: MNEMOSYNE.y, r: 550, name: 'MNEMOSYNE LIBRARY', sub: 'THE LAST WATCH / THE FIRST OATH / THE SECOND DAWN', secret: true, gates: libraryDoors });
  for (const side of [0, 1]) for (let i = 0; i < 4; i++) {
    prop(library, 'books', archive.x + (side ? archive.w - 300 : 70), archive.y + 70 + i * 147, 224, 67, true, '#bba079');
  }
  prop(library, 'table', MNEMOSYNE.x - 74, MNEMOSYNE.y - 70, 148, 110, true, '#d6b982');
  const volumes: LibraryVolume[] = [
    { x: MNEMOSYNE.x - 143, y: MNEMOSYNE.y - 206, number: 1, read: false },
    { x: MNEMOSYNE.x + 143, y: MNEMOSYNE.y + 202, number: 2, read: false },
    { x: MNEMOSYNE.x + 143, y: MNEMOSYNE.y - 206, number: 3, read: false },
  ];
  ['sentinel', 'pathfinder', 'guard', 'warden', 'guard', 'medic'].forEach((type, i) => c.guards.push({
    x: MNEMOSYNE.x + (i % 2 ? 94 : -94), y: archive.y + 155 + Math.floor(i / 2) * 203,
    type, facilityId: 'mnemosyne', role: i === 0 ? 'leader' : i === 5 ? 'support' : 'sentry', patrol: [],
  }));
  c.caches.push({ x: MNEMOSYNE.x - 80, y: archive.y + archive.h - 92 });
  return { warehouse: depot, library: archive, volumes, librarySolved: false, libraryProgress: 0, patrols: [
    { id: 'goliath-patrol', points: [{ x: depot.x + 120, y: depot.y + 550 }, { x: depot.x + depot.w - 120, y: depot.y + 550 }, { x: depot.x + depot.w - 120, y: depot.y + 1065 }, { x: depot.x + 120, y: depot.y + 1065 }], members: ['commander', 'warden', 'grunt', 'grunt', 'gunner', 'pathfinder', 'grunt', 'medic'] },
    { id: 'goliath-gate', points: [{ x: GOLIATH.x - 460, y: depot.y + depot.h - 90 }, { x: GOLIATH.x + 470, y: depot.y + depot.h - 90 }], members: ['warden', 'breacher', 'grunt', 'grunt', 'gunner', 'guard', 'pathfinder', 'medic'] },
  ] };
}